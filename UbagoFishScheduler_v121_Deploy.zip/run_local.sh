#!/bin/bash
pip install -r requirements.txt
streamlit run ubagofish_scheduler.py
